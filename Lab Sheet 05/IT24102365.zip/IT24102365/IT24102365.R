# Lab 05 - IT2120: Probability and Statistics
# Student: IT24102365

# Set working directory (update path as needed)
setwd("C:\\Users\\Menura Lakvindu\\Desktop\\IT24102365")

# 1. Import data
Delivery_Times <- read.table("Exercise - Lab 05.txt", header = TRUE)

# View data
fix(Delivery_Times)
attach(Delivery_Times)

# 2. Histogram with 9 classes from 20 to 70, right-open
histogram <- hist(Delivery_Times$Delivery_Time_.minutes., 
                  main = "Histogram of Delivery Times",
                  xlab = "Delivery Time (minutes)",
                  breaks = seq(20, 70, length = 10),
                  right = FALSE)

# 3. Comment on the shape of the distribution
# The distribution appears to be approximately symmetric with a slight right skew.
# Most delivery times are clustered around 35-50 minutes, with fewer very short
# (20-25 minutes) and very long (60-70 minutes) delivery times.

# 4. Draw cumulative frequency polygon (ogive) in a separate plot
# Calculate cumulative frequencies
breaks <- round(histogram$breaks)
freq <- histogram$counts
cum_freq <- cumsum(freq)

# Create cumulative frequency data for ogive
ogive_data <- c(0, cum_freq)

# Plot the ogive
plot(breaks, ogive_data, 
     type = "l", 
     main = "Cumulative Frequency Polygon (Ogive) of Delivery Times",
     xlab = "Delivery Time (minutes)", 
     ylab = "Cumulative Frequency",
     col = "blue",
     lwd = 2)

# Add points at each breakpoint
points(breaks, ogive_data, col = "red", pch = 16)

# Add grid for better readability
grid()
