setwd("C:\\Users\\Menura Lakvindu\\Desktop\\IT24102365")

#Question 1
#Uniform distribution: min=0, max=40

# P(10 ≤ X ≤ 25)
punif(25, min = 0, max = 40) - punif(10, min = 0, max = 40)


#Question 2
lambda <- 1/3
x <- 2
pexp(x, rate = lambda, lower.tail = TRUE)

#Question 3
# i)
m <- 100
sigma <- 15
pnorm(130, mean = m, sd = sigma, lower.tail = FALSE)
# or
1- pnorm(130, mean = m, sd = sigma, lower.tail = TRUE)

# ii)
qnorm(0.95, mean = m, sd = sigma, lower.tail = TRUE)
