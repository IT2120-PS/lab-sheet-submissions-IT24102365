getwd()
setwd("C:\\Users\\Menura Lakvindu\\Desktop\\IT24102365")
getwd()

data<-read.table("Exercise - LaptopsWeights.txt",header = TRUE)
fix(data)
attach(data)

#1.
pop_mean <- mean(Weight.kg.)
pop_sd <- sqrt(mean((Weight.kg. - pop_mean)^2))

cat("Population mean: ", pop_mean, "\n")
cat("Population standard deviation: ", pop_sd, "\n")

#2.
samples <- c()
n <- c()
for(i in 1:25) {
  s <- sample(Weight.kg., 6, replace=TRUE)
  samples <- cbind(samples, s)
  n <- c(n, paste('s', i))
}
colnames(samples) <- n
samples

s.means <- apply(samples, 2, mean)
s.sds <- apply(samples, 2, sd)

cat("25 sample means: ", s.means)
cat("25 sample means standard deviation: ", s.sds)


#3.
mean_sample_means <- mean(s.means)
sd_sample_means <- sd(s.means)

cat("Mean of the 25 sample means: ", mean_sample_means)
cat("Standard deviation of the 25 sample means: ", sd_sample_means)

theoretical_sd <- pop_sd / sqrt(6)

cat("THEORETICAL VERIFICATION:\n")
cat("Population mean (μ): ", pop_mean, "\n")
cat("Mean of sample means: ", mean_sample_means, "\n")
cat("Difference: ", mean_sample_means - pop_mean, "\n\n")

cat("SD of sample population: ", theoretical_sd, "\n")
cat("SD of sample means: ", sd_sample_means, "\n")
cat("Difference: ", sd_sample_means - theoretical_sd, "\n")
