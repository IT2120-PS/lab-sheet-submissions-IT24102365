setwd("C:\\Users\\Menura Lakvindu\\Desktop\\IT24102365")

#Question 01:
n <- 50
p <- 0.85

# i)
# Binomial distribution (n = 50, p = 0.85)

# ii)
1-pbinom(47, 50, 0.85, lower.tail = TRUE)

#Question 02

# i) 
# Random variable = number of customer calls per hour

#ii)
# Poisson distribution with lambda = 12

#iii)
dpois(15, 12)

